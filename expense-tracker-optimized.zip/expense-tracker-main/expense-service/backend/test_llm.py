#!/usr/bin/env python3
"""
Test script to verify GPT4All model loading
"""
import sys
import os
sys.path.append('/Users/ankit_chauhan/Desktop/expense-tracker/expense-service/backend')

from app.tasks import get_llm, generate_chat_response

def test_llm():
    print("Testing LLM initialization...")
    
    # Test LLM loading
    llm = get_llm()
    print(f"LLM instance: {llm}")
    print(f"LLM type: {type(llm)}")
    
    if llm != "mock":
        print("✅ LLM loaded successfully!")
        
        # Test a simple generation
        try:
            test_prompt = "Hello, how are you?"
            response = llm.generate(test_prompt, max_tokens=50)
            print(f"Test response: {response}")
        except Exception as e:
            print(f"❌ LLM generation failed: {e}")
    else:
        print("⚠️ Using mock/fallback mode")
    
    # Test chat response
    print("\nTesting chat response...")
    test_data = {
        "total_spent": 100.0,
        "spend_by_category": {"food": 60.0, "transport": 40.0},
        "expenses": [
            {"description": "Lunch", "amount": 60.0, "category": "food"},
            {"description": "Bus fare", "amount": 40.0, "category": "transport"}
        ]
    }
    
    response = generate_chat_response("How much did I spend on food?", test_data)
    print(f"Chat response: {response}")

if __name__ == "__main__":
    test_llm()
