from sqlalchemy import Column, String, Float, Enum, DateTime, JSON
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.ext.declarative import declarative_base
import enum
import uuid
from datetime import datetime

Base = declarative_base()

class ExpenseStatus(enum.Enum):
    PENDING = "PENDING"
    PAID = "PAID"
    REIMBURSED = "REIMBURSED"
    REJECTED = "REJECTED"  # Added missing status

class Expense(Base):
    __tablename__ = "expenses"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    employee_id = Column(UUID(as_uuid=True), nullable=False)
    amount = Column(Float, nullable=False)
    category = Column(String, nullable=False)
    description = Column(String, nullable=True)
    receipt_url = Column(String, nullable=True)
    upi_qr_url = Column(String, nullable=True)
    ocr_data = Column(JSON, nullable=True)
    status = Column(Enum(ExpenseStatus), default=ExpenseStatus.PENDING)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class PaymentLog(Base):
    __tablename__ = "payment_logs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    expense_id = Column(UUID(as_uuid=True), nullable=False)
    action = Column(Enum(ExpenseStatus), nullable=False)
    user_id = Column(UUID(as_uuid=True), nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)
    reference = Column(String, nullable=True)
