import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# Get the absolute path to the backend directory
backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
database_path = os.path.join(backend_dir, "data", "expenses.db")

SQLALCHEMY_DATABASE_URL = f"sqlite:///{database_path}"

engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def create_tables():
    from .models import Base
    Base.metadata.create_all(bind=engine)
