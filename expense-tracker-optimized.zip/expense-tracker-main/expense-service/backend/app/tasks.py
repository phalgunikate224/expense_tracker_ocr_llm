from celery import Celery
import logging
import os
from PIL import Image
import pytesseract

celery = Celery(
    "tasks",
    broker="redis://localhost:6379/0",
    backend="redis://localhost:6379/0"
)

# Initialize LLM lazily to avoid startup errors
llm = None

def get_llm():
    global llm
    if llm is None:
        try:
            from gpt4all import GPT4All
            # Use a smaller, more commonly available model
            # Try multiple models in order of preference
            model_names = [
                "orca-mini-3b-gguf2-q4_0.gguf",
                "gpt4all-falcon-newbpe-q4_0.gguf", 
                "nous-hermes-llama2-13b.q4_0.bin",
                "wizardlm-13b-v1.2.q4_0.bin"
            ]
            
            llm_instance = None
            for model_name in model_names:
                try:
                    logging.info(f"Attempting to load model: {model_name}")
                    llm_instance = GPT4All(model_name, allow_download=True)
                    logging.info(f"Successfully loaded model: {model_name}")
                    break
                except Exception as model_error:
                    logging.warning(f"Failed to load model {model_name}: {model_error}")
                    continue
            
            if llm_instance is None:
                raise Exception("No suitable LLM model could be loaded")
                
            llm = llm_instance
            
        except Exception as e:
            logging.warning(f"Could not initialize LLM: {e}")
            llm = "mock"  # Use mock for testing
    return llm

@celery.task
def process_receipt(file_path):
    """
    Perform OCR on the uploaded receipt image and extract structured data.
    Args:
        file_path (str): Path to the uploaded image file.
    Returns:
        dict: Extracted data including merchant, date, total, and line items if possible.
    """
    import re
    try:
        logging.info(f"[process_receipt] Starting OCR for file: {file_path}")
        if not os.path.exists(file_path):
            logging.error(f"[process_receipt] File does not exist: {file_path}")
            return {"status": "error", "error": f"File not found: {file_path}"}
        # Open the image file
        image = Image.open(file_path)
        logging.info(f"[process_receipt] Image opened successfully: {file_path}")
        # Run OCR
        ocr_text = pytesseract.image_to_string(image)
        logging.info(f"[process_receipt] OCR completed. Text length: {len(ocr_text)}")
        lines = [line.strip() for line in ocr_text.split('\n') if line.strip()]
        merchant = None
        total = None
        date = None
        items = []
        # Improved regexes
        date_regex = re.compile(r'(\d{2,4}[/-]\d{1,2}[/-]\d{1,4})')
        total_regex = re.compile(r'(total|amount|grand total)[^\d]*(\$?\d+[\.,]?\d*)', re.IGNORECASE)
        price_regex = re.compile(r'(\$?\d+[\.,]\d{2})')
        # Try to find merchant (first non-numeric, non-keyword line)
        for line in lines:
            if not any(word in line.lower() for word in ["total", "amount", "date", "item", "qty", "price"]):
                if not re.search(r'\d', line):
                    merchant = line
                    break
        # Find date
        for line in lines:
            match = date_regex.search(line)
            if match:
                date = match.group(1)
                break
        # Find total (look for last matching line)
        for line in reversed(lines):
            match = total_regex.search(line)
            if match:
                try:
                    total = float(match.group(2).replace('$', '').replace(',', ''))
                    break
                except Exception:
                    continue
            # Fallback: look for a price at the end
            price_match = price_regex.search(line)
            if price_match and ("total" in line.lower() or "amount" in line.lower()):
                try:
                    total = float(price_match.group(1).replace('$', '').replace(',', ''))
                    break
                except Exception:
                    continue
        # Extract line items (lines with both text and price, but not total)
        for line in lines:
            if (price_regex.search(line) and not any(word in line.lower() for word in ["total", "amount"])):
                # Try to split item and price
                parts = re.split(price_regex, line)
                price = price_regex.search(line).group(1)
                item_name = parts[0].strip() if parts[0].strip() else line.strip()
                # Try to extract quantity if present (e.g. "2x Coffee - $5.00")
                qty_match = re.match(r'(\d+)x?\s*(.*)', item_name, re.IGNORECASE)
                if qty_match:
                    quantity = int(qty_match.group(1))
                    item_desc = qty_match.group(2).strip()
                    items.append({"name": item_desc, "price": price, "quantity": quantity})
                else:
                    items.append({"name": item_name, "price": price, "quantity": 1})
        # Fallbacks
        if not merchant and lines:
            merchant = lines[0]
        logging.info(f"[process_receipt] Extraction complete. Merchant: {merchant}, Date: {date}, Total: {total}, Items: {len(items)}")
        return {
            "status": "processed",
            "ocr_text": ocr_text,
            "merchant": merchant,
            "date": date,
            "total": total,
            "items": items
        }
    except Exception as e:
        logging.error(f"[process_receipt] Exception: {e}")
        return {"status": "error", "error": str(e)}

@celery.task
def generate_summary(user_id: str, expenses: list):
    context = "\n".join([f"Expense: {expense['description']}, Amount: {expense['amount']}, Category: {expense['category']}" for expense in expenses])
    prompt = f"Summarize the following expenses:\n{context}\nProvide total spend by category and flag anomalies."
    
    llm_instance = get_llm()
    if llm_instance == "mock":
        return {"summary": "Mock summary: Unable to load LLM model. Manual review required."}
    
    try:
        response = llm_instance.generate(prompt)
        return {"summary": response}
    except Exception as e:
        logging.error(f"LLM generation failed: {e}")
        return {"summary": "Error generating summary. Manual review required."}

def generate_chat_response(question: str, expenses_data: dict) -> str:
    """
    Generate a natural language response to user questions about expenses
    using the local LLM with RAG techniques
    """
    try:
        llm = get_llm()
        # Log which mode is being used
        logging.info(f"LLM mode: {'mock (fallback)' if llm == 'mock' else 'LLM'}")
        if llm == "mock":
            return generate_fallback_response(question, expenses_data)
        
        # Create a concise context from expenses data
        total_spent = expenses_data.get('total_spent', 0)
        categories = expenses_data.get('spend_by_category', {})
        expense_count = len(expenses_data.get('expenses', []))
        
        # Build category breakdown text
        category_text = ", ".join([f"{cat}: ${amt:.2f}" for cat, amt in categories.items()])
        
        # Create a focused, concise prompt
        prompt = f"""You are an expense tracking assistant. Answer the user's question using only the provided data.

Expense Data:
- Total spent: ${total_spent:.2f}
- Number of expenses: {expense_count}
- Categories: {category_text}

User Question: {question}

Provide a direct, helpful answer based only on this data. Be concise and accurate.

Answer:"""
        
        # Generate response using the LLM with constrained parameters
        try:
            response = llm.generate(prompt, max_tokens=100, temp=0.3)
            
            # Clean up the response
            answer = response.strip()
            
            # If response is too long or seems off-topic, use fallback
            if len(answer) > 300 or not answer:
                return generate_fallback_response(question, expenses_data)
                
            return answer
            
        except Exception as llm_error:
            logging.error(f"LLM generation error: {llm_error}")
            return generate_fallback_response(question, expenses_data)
        
    except Exception as e:
        logging.error(f"Chat response generation failed: {e}")
        return generate_fallback_response(question, expenses_data)

def generate_fallback_response(question: str, expenses_data: dict) -> str:
    """
    Generate a simple rule-based response when LLM is not available
    """
    question_lower = question.lower()
    total_spent = expenses_data.get('total_spent', 0)
    categories = expenses_data.get('spend_by_category', {})
    expense_count = len(expenses_data.get('expenses', []))
    pending_expenses = [e for e in expenses_data.get('expenses', []) if e.get('status', '').lower() == 'pending']
    pending_total = sum(e.get('amount', 0) for e in pending_expenses)
    pending_count = len(pending_expenses)
    pending_by_category = {}
    for e in pending_expenses:
        cat = e.get('category', 'uncategorized')
        pending_by_category[cat] = pending_by_category.get(cat, 0) + e.get('amount', 0)

    # Pending expenses summary
    if 'pending' in question_lower:
        if pending_count == 0:
            return "There are no pending expenses."
        lines = [
            f"Pending Expenses Summary\n",
            f"- Total Spent: ${pending_total:.2f}",
            f"- Expense Count: {pending_count}",
            f"- Category Breakdown:"
        ]
        for cat, amt in pending_by_category.items():
            lines.append(f"  - {cat}: ${amt:.2f}")
        return "\n".join(lines)

    # Check for specific category mentions
    for category_name, amount in categories.items():
        if category_name.lower() in question_lower:
            if 'month' in question_lower:
                return f"You spent ${amount:.2f} on {category_name} this month."
            else:
                return f"You spent ${amount:.2f} on {category_name}."
    
    if 'total' in question_lower or 'much' in question_lower:
        if 'month' in question_lower:
            return f"Based on the available data, the total spending this month is ${total_spent:.2f}. This includes expenses across {len(categories)} categories: {', '.join([f'{cat} (${amt:.2f})' for cat, amt in categories.items()])}."
        else:
            return f"The total amount spent is ${total_spent:.2f}."
    
    elif 'category' in question_lower or 'categories' in question_lower:
        if categories:
            category_summary = ", ".join([f"{cat}: ${amount:.2f}" for cat, amount in categories.items()])
            return f"Here's the breakdown by category: {category_summary}"
        else:
            return "No category data available."
    
    elif 'highest' in question_lower or 'most' in question_lower:
        if categories:
            highest_category = max(categories.items(), key=lambda x: x[1])
            return f"The highest spending category is {highest_category[0]} with ${highest_category[1]:.2f}."
        else:
            return "No category data available to determine the highest spending."
    
    else:
        return f"Based on the available expense data: Total spent is ${total_spent:.2f} across {len(categories)} categories. You can ask about totals, categories, or specific spending patterns."
