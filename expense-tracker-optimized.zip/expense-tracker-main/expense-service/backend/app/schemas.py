from pydantic import BaseModel
from typing import Optional
from uuid import UUID
from datetime import datetime
from .models import ExpenseStatus

class ExpenseBase(BaseModel):
    description: Optional[str]
    amount: float
    category: str

class ExpenseCreate(ExpenseBase):
    pass

class Expense(ExpenseBase):
    id: UUID
    employee_id: UUID
    receipt_url: Optional[str]
    upi_qr_url: Optional[str]
    ocr_data: Optional[dict]
    status: ExpenseStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

class ExpenseStatusUpdate(BaseModel):
    status: ExpenseStatus

class SummaryRequest(BaseModel):
    user_id: str
    question: str  # Natural language question like "How much did I spend this month?"
    from_date: Optional[str] = None
    to_date: Optional[str] = None

class SummaryResponse(BaseModel):
    question: str
    answer: str  # Natural language response from LLM
    data: dict  # Supporting data (totals, categories, etc.)

class ChatRequest(BaseModel):
    question: str

class ChatResponse(BaseModel):
    answer: str
    data: dict = {}  # Additional structured data if needed
