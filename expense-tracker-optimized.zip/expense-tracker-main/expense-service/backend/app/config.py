import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    BACKEND_PORT = os.getenv("BACKEND_PORT", 8000)
    DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./test.db")
    REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
    HRMS_JWKS_URL = os.getenv("HRMS_JWKS_URL", "https://hrms.example.com/.well-known/jwks.json")
