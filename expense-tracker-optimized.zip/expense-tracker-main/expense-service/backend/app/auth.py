from fastapi import Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
from jose import jwt, JWTError
import requests

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

HRMS_JWKS_URL = "https://hrms.example.com/.well-known/jwks.json"

# Cache for the JWKS
jwks_cache = None

# Function to get the JWKS
def get_jwks():
    global jwks_cache
    if jwks_cache is None:
        response = requests.get(HRMS_JWKS_URL)
        if response.status_code != 200:
            raise HTTPException(status_code=401, detail="Invalid token")
        jwks_cache = response.json()
    return jwks_cache

STATIC_USERS = {
    "admin": "admin"  # username: password
}

# Function to validate the JWT token
def validate_jwt(token: str = Depends(oauth2_scheme)):
    if token in STATIC_USERS.values():
        return {"username": "admin", "role": "admin"}
    raise HTTPException(status_code=401, detail="Invalid token")
