from sqlalchemy.orm import Session
import uuid
from . import models, schemas

def get_expenses(db: Session, skip: int = 0, limit: int = 10):
    return db.query(models.Expense).offset(skip).limit(limit).all()

def create_expense(db: Session, expense: schemas.ExpenseCreate, user_id: uuid.UUID):
    db_expense = models.Expense(**expense.dict(), employee_id=user_id)
    db.add(db_expense)
    db.commit()
    db.refresh(db_expense)
    return db_expense

def update_expense_status(db: Session, expense_id: str, status: models.ExpenseStatus):
    try:
        expense_uuid = uuid.UUID(expense_id)
        expense = db.query(models.Expense).filter(models.Expense.id == expense_uuid).first()
        if expense:
            expense.status = status
            db.commit()
            db.refresh(expense)
        return expense
    except ValueError:
        # Invalid UUID format
        return None
