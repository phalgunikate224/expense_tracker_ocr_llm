from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, BackgroundTasks
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
import uuid
from . import models, schemas, crud, deps
from .auth import validate_jwt, STATIC_USERS
from .tasks import process_receipt, generate_summary, generate_chat_response
from .database import create_tables
from fastapi.middleware.cors import CORSMiddleware
import os
from uuid import uuid4
from fastapi.responses import JSONResponse
from celery.result import AsyncResult

app = FastAPI()

# Initialize database tables
create_tables()

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],  # Frontend origin
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.get("/")
def read_root():
    return {"message": "Welcome to the Expense Tracker API"}

@app.post("/expenses/", response_model=schemas.Expense)
def create_expense(expense: schemas.ExpenseCreate, db: Session = Depends(deps.get_db), token: str = Depends(validate_jwt)):
    # Generate a UUID for the user (in production, this would come from the JWT token)
    user_uuid = uuid.uuid4()
    created_expense = crud.create_expense(db=db, expense=expense, user_id=user_uuid)
    process_receipt.delay(str(created_expense.id))  # Enqueue background task
    return created_expense

@app.get("/expenses/", response_model=list[schemas.Expense])
def list_expenses(skip: int = 0, limit: int = 10, db: Session = Depends(deps.get_db)):
    return crud.get_expenses(db=db, skip=skip, limit=limit)

@app.patch("/expenses/{expense_id}/status", response_model=schemas.Expense)
def update_expense_status(expense_id: str, status_update: schemas.ExpenseStatusUpdate, db: Session = Depends(deps.get_db), token: str = Depends(validate_jwt)):
    updated_expense = crud.update_expense_status(db=db, expense_id=expense_id, status=status_update.status)
    if not updated_expense:
        raise HTTPException(status_code=404, detail="Expense not found")
    return updated_expense

@app.post("/summaries/", response_model=schemas.SummaryResponse)
def get_summary(request: schemas.SummaryRequest, db: Session = Depends(deps.get_db), token: str = Depends(validate_jwt)):
    expenses = crud.get_expenses(db=db, skip=0, limit=100)  # Fetch all expenses for the user
    
    # Convert expenses to dict format for processing
    expense_dicts = []
    for expense in expenses:
        expense_dicts.append({
            "description": expense.description,
            "amount": expense.amount,
            "category": expense.category,
            "status": expense.status.value if expense.status else "PENDING"
        })
    
    # Calculate totals and categories
    total_spent = sum(exp["amount"] for exp in expense_dicts)
    spend_by_category = {}
    for exp in expense_dicts:
        category = exp["category"]
        spend_by_category[category] = spend_by_category.get(category, 0) + exp["amount"]
    
    # Prepare data for LLM
    expenses_data = {
        "expenses": expense_dicts,
        "total_spent": total_spent,
        "spend_by_category": spend_by_category
    }
    
    # Generate LLM response to the question
    answer = generate_chat_response(request.question, expenses_data)
    
    return schemas.SummaryResponse(
        question=request.question,
        answer=answer,
        data={
            "total_spent": total_spent,
            "spend_by_category": spend_by_category,
            "expense_count": len(expense_dicts)
        }
    )

@app.post("/chat/", response_model=schemas.ChatResponse)
def chat_with_expenses(request: schemas.ChatRequest, db: Session = Depends(deps.get_db), token: str = Depends(validate_jwt)):
    """
    Chat endpoint for natural language queries about expenses
    """
    expenses = crud.get_expenses(db=db, skip=0, limit=100)
    
    # Convert expenses to dict format
    expense_dicts = []
    for expense in expenses:
        expense_dicts.append({
            "description": expense.description,
            "amount": expense.amount,
            "category": expense.category,
            "status": expense.status.value if expense.status else "PENDING",
            "created_at": expense.created_at.isoformat() if expense.created_at else None
        })
    
    # Calculate summary data
    total_spent = sum(exp["amount"] for exp in expense_dicts)
    spend_by_category = {}
    for exp in expense_dicts:
        category = exp["category"]
        spend_by_category[category] = spend_by_category.get(category, 0) + exp["amount"]
    
    # Prepare data for LLM
    expenses_data = {
        "expenses": expense_dicts,
        "total_spent": total_spent,
        "spend_by_category": spend_by_category
    }
    
    # Generate response
    answer = generate_chat_response(request.question, expenses_data)
    
    return schemas.ChatResponse(
        answer=answer,
        data={
            "total_spent": total_spent,
            "spend_by_category": spend_by_category,
            "expense_count": len(expense_dicts)
        }
    )

@app.post("/token")
def login(form_data: OAuth2PasswordRequestForm = Depends()):
    username = form_data.username
    password = form_data.password
    
    if username in STATIC_USERS and STATIC_USERS[username] == password:
        # Return the password as token for simplicity (in production, use proper JWT)
        return {"access_token": password, "token_type": "bearer"}
    
    raise HTTPException(status_code=401, detail="Invalid credentials")

@app.post("/upload-receipt/")
async def upload_receipt(background_tasks: BackgroundTasks, file: UploadFile = File(...)):
    # Save uploaded file
    ext = os.path.splitext(file.filename)[-1]
    filename = f"receipt_{uuid4().hex}{ext}"
    file_path = os.path.join(UPLOAD_DIR, filename)
    with open(file_path, "wb") as f:
        content = await file.read()
        f.write(content)
    # Trigger Celery OCR task
    task = process_receipt.delay(file_path)
    return {"task_id": task.id, "status": "processing"}

@app.get("/receipt-result/{task_id}")
def get_receipt_result(task_id: str):
    """
    Fetch the result of the OCR processing task by Celery task ID.
    """
    result = AsyncResult(task_id, app=process_receipt.app)
    if result.state == "PENDING":
        return {"status": "pending"}
    elif result.state == "STARTED":
        return {"status": "processing"}
    elif result.state == "FAILURE":
        return {"status": "error", "error": str(result.info)}
    elif result.state == "SUCCESS":
        return {"status": "done", "data": result.result}
    else:
        return {"status": result.state.lower()}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8080, reload=True)
