# Expense Tracker

A modern, full-stack expense tracking system with AI-powered receipt OCR and natural language analytics.

## Features

- **Expense Management:** Add, view, and categorize expenses with status tracking (Pending, Paid, Reimbursed, Rejected).
- **Receipt OCR:** Upload receipt images and extract merchant, date, total, and line items using Tesseract OCR.
- **AI Assistant:** Ask questions about your expenses using a local LLM (with fallback to rule-based answers).
- **Analytics:** Visualize spending by category, status, and trends.
- **Authentication:** Secure login with JWT.
- **Modern UI:** Built with React and Tailwind CSS.

## Tech Stack

- **Frontend:** React, Tailwind CSS
- **Backend:** FastAPI, SQLAlchemy, Celery, Redis
- **OCR:** Tesseract (via pytesseract)
- **AI:** gpt4all (local LLM) with fallback logic
- **Database:** SQLite (default, can be swapped)

## Quick Start

### Prerequisites
- Python 3.9+
- Node.js 16+
- Redis (for Celery)
- Tesseract OCR (`brew install tesseract` on macOS)

### Backend Setup
```bash
cd expense-service/backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
# Start FastAPI
uvicorn app.main:app --reload
# Start Celery worker (in another terminal)
celery -A app.tasks worker --loglevel=info
```

### Frontend Setup
```bash
cd expense-service/frontend
npm install
npm start
```

### Usage
- Visit `http://localhost:3000` for the frontend.
- Login or register.
- Add expenses, upload receipts, and interact with the AI assistant.

### Receipt OCR
- Upload a receipt image in the "Add Expense" form.
- The backend will extract merchant, date, total, and line items.
- You can confirm or edit the extracted data before saving.

### AI Assistant
- Ask questions like "What are my pending expenses?" or "How much did I spend on meals this month?"
- The system uses a local LLM if available, otherwise falls back to rule-based answers.

## Project Structure

```
expense-service/
  backend/
    app/
      main.py         # FastAPI app
      tasks.py        # Celery tasks (OCR, LLM)
      models.py       # SQLAlchemy models
      schemas.py      # Pydantic schemas
      ...
    requirements.txt
    Dockerfile
  frontend/
    src/
      App.jsx         # Main React app
      components/     # UI components
      hooks/          # React hooks
      utils/          # API and helpers
    package.json
```

## Troubleshooting
- **OCR Timeout:** Ensure Tesseract is installed and the Celery worker is running.
- **422 on status update:** Make sure the backend enum includes all statuses (PENDING, PAID, REIMBURSED, REJECTED).
- **LLM fallback:** If the LLM cannot load, the system will use rule-based answers and log this in the backend.

## Contributing
Pull requests are welcome! Please open an issue first to discuss major changes.

## License
MIT
