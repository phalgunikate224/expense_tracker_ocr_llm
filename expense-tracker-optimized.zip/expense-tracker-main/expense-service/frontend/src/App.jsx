import React, { useState, useEffect } from 'react';
import { useAuth } from './hooks/useAuth';
import { useExpenses } from './hooks/useExpenses';

// Components
import LoginForm from './components/auth/LoginForm';
import Header from './components/ui/Header';
import ExpenseForm from './components/expenses/ExpenseForm';
import ExpenseList from './components/expenses/ExpenseList';
import ChatInterface from './components/chat/ChatInterface';
import Analytics from './components/analytics/Analytics';

function App() {
  const [activeTab, setActiveTab] = useState('expenses');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [chatError, setChatError] = useState(null);
  
  // Authentication state from custom hook
  const { 
    token, 
    isAuthenticated, 
    loading: authLoading, 
    error: authError, 
    login, 
    logout 
  } = useAuth();
  
  // Expenses state from custom hook
  const { 
    expenses, 
    loading: expensesLoading, 
    error: expensesError, 
    fetchExpenses, 
    createExpense, 
    updateExpenseStatus,
    chatWithExpenses 
  } = useExpenses(token);

  // Handle login submission
  const handleLogin = async (username, password) => {
    return await login(username, password);
  };

  // Handle expense creation
  const handleAddExpense = async (expense) => {
    return await createExpense(expense);
  };

  // Handle chat message submission
  const handleSendChatMessage = async (question) => {
    try {
      setChatError(null);
      return await chatWithExpenses(question);
    } catch (error) {
      setChatError(error.message || 'Failed to get a response');
      throw error;
    }
  };

  // Toggle sidebar for mobile view
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  // If not authenticated, show login screen
  if (!isAuthenticated) {
    return (
      <LoginForm 
        onLogin={handleLogin}
        loading={authLoading}
        error={authError}
      />
    );
  }

  // Main application layout
  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <Header 
        onLogout={logout} 
        onToggleSidebar={toggleSidebar}
      />
      
      <div className="flex-1 flex flex-col md:flex-row">
        {/* Sidebar / Navigation */}
        <div className={`
          bg-white shadow-sm w-full md:w-64 md:flex-shrink-0 
          md:block transition-all duration-300 ease-in-out
          ${sidebarOpen ? 'block' : 'hidden'}
        `}>
          <div className="p-4">
            <nav className="space-y-1">
              {[
                { id: 'expenses', label: 'Expenses' },
                { id: 'chat', label: 'AI Assistant' },
                { id: 'analytics', label: 'Analytics' },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setSidebarOpen(false);
                  }}
                  className={`flex items-center px-3 py-2 w-full text-sm font-medium rounded-md
                    ${activeTab === item.id 
                      ? 'bg-blue-50 text-blue-700' 
                      : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                    }
                  `}
                >
                  {item.label}
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Main content area */}
        <main className="flex-1 p-4 overflow-auto">
          <div className="max-w-7xl mx-auto">
            {/* Expenses tab */}
            {activeTab === 'expenses' && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Expense form */}
                  <div className="lg:col-span-1">
                    <ExpenseForm
                      onSubmit={handleAddExpense}
                      loading={expensesLoading}
                      error={expensesError}
                    />
                  </div>
                  
                  {/* Expense list */}
                  <div className="lg:col-span-2">
                    <ExpenseList
                      expenses={expenses}
                      onUpdateStatus={updateExpenseStatus}
                      onRefresh={fetchExpenses}
                      loading={expensesLoading}
                      error={expensesError}
                    />
                  </div>
                </div>
              </div>
            )}
            
            {/* Chat tab */}
            {activeTab === 'chat' && (
              <div className="bg-white shadow-sm rounded-lg overflow-hidden" style={{ height: 'calc(100vh - 140px)' }}>
                <ChatInterface
                  onSendMessage={handleSendChatMessage}
                  loading={expensesLoading}
                  error={chatError}
                />
              </div>
            )}
            
            {/* Analytics tab */}
            {activeTab === 'analytics' && (
              <Analytics
                expenses={expenses}
                loading={expensesLoading}
                error={expensesError}
              />
            )}
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;