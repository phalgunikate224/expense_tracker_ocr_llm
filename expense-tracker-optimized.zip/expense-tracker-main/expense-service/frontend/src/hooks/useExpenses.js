import { useState, useEffect, useCallback } from 'react';
import { api } from '../utils/api';

export const useExpenses = (token) => {
  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Fetch expenses
  const fetchExpenses = useCallback(async () => {
    if (!token) return;
    
    setLoading(true);
    setError(null);
    
    try {
      const data = await api.getExpenses(token);
      setExpenses(data || []);
    } catch (err) {
      setError(err.message || 'Failed to fetch expenses');
      console.error('Error fetching expenses:', err);
    } finally {
      setLoading(false);
    }
  }, [token]);

  // Create a new expense
  const createExpense = async (expense) => {
    setLoading(true);
    setError(null);
    
    try {
      await api.createExpense(token, expense);
      await fetchExpenses();
      return true;
    } catch (err) {
      setError(err.message || 'Failed to create expense');
      console.error('Error creating expense:', err);
      return false;
    } finally {
      setLoading(false);
    }
  };

  // Update expense status
  const updateExpenseStatus = async (expenseId, status) => {
    setLoading(true);
    setError(null);
    
    try {
      await api.updateExpenseStatus(token, expenseId, status);
      await fetchExpenses();
      return true;
    } catch (err) {
      setError(err.message || 'Failed to update expense status');
      console.error('Error updating expense status:', err);
      return false;
    } finally {
      setLoading(false);
    }
  };

  // Chat with AI about expenses
  const chatWithExpenses = async (question) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await api.chatWithExpenses(token, question);
      return response;
    } catch (err) {
      setError(err.message || 'Failed to get chat response');
      console.error('Error with chat:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Initial fetch
  useEffect(() => {
    if (token) {
      fetchExpenses();
    }
  }, [token, fetchExpenses]);

  return {
    expenses,
    loading,
    error,
    fetchExpenses,
    createExpense,
    updateExpenseStatus,
    chatWithExpenses
  };
};