import { useState, useEffect } from 'react';
import { api } from '../utils/api';

export const useAuth = () => {
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [isAuthenticated, setIsAuthenticated] = useState(!!token);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const login = async (username, password) => {
    setLoading(true);
    setError(null);
    
    try {
      const data = await api.login(username, password);
      setToken(data.access_token);
      localStorage.setItem('token', data.access_token);
      setIsAuthenticated(true);
      return { success: true };
    } catch (err) {
      setError(err.message || 'Authentication failed');
      return { success: false, error: err.message || 'Authentication failed' };
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    setToken(null);
    localStorage.removeItem('token');
    setIsAuthenticated(false);
    setError(null);
  };

  return {
    token,
    isAuthenticated,
    loading,
    error,
    login,
    logout
  };
};
