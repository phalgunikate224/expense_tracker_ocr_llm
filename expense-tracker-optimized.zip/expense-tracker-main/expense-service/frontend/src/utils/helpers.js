/**
 * Utility functions for calculations and data manipulation
 */

export const formatCurrency = (amount) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2
  }).format(amount);
};

export const formatDate = (dateString) => {
  return new Date(dateString).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
};

export const formatDateTime = (dateString) => {
  return new Date(dateString).toLocaleString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
};

export const calculateExpenseStats = (expenses) => {
  if (!expenses || expenses.length === 0) {
    return {
      total: 0,
      count: 0,
      average: 0,
      byCategory: {},
      byStatus: {},
      recent: []
    };
  }

  const total = expenses.reduce((sum, expense) => sum + expense.amount, 0);
  const count = expenses.length;
  const average = total / count;

  const byCategory = expenses.reduce((acc, expense) => {
    const category = expense.category || 'Other';
    acc[category] = (acc[category] || 0) + expense.amount;
    return acc;
  }, {});

  const byStatus = expenses.reduce((acc, expense) => {
    const status = expense.status || 'UNKNOWN';
    acc[status] = (acc[status] || 0) + 1;
    return acc;
  }, {});

  const recent = expenses
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
    .slice(0, 5);

  return {
    total,
    count,
    average,
    byCategory,
    byStatus,
    recent
  };
};

export const validateExpense = (expense) => {
  const errors = {};

  if (!expense.description || expense.description.trim().length === 0) {
    errors.description = 'Description is required';
  }

  if (!expense.amount || expense.amount <= 0) {
    errors.amount = 'Amount must be greater than 0';
  }

  if (!expense.category || expense.category.trim().length === 0) {
    errors.category = 'Category is required';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
};

export const getStatusColor = (status) => {
  switch (status) {
    case 'PAID':
      return 'bg-green-100 text-green-800';
    case 'REJECTED':
      return 'bg-red-100 text-red-800';
    case 'PENDING':
      return 'bg-yellow-100 text-yellow-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
};

export const getCategoryIcon = (category) => {
  const icons = {
    meals: '🍽️',
    transportation: '🚗',
    office: '🏢',
    travel: '✈️',
    entertainment: '🎭',
    other: '📋'
  };
  return icons[category] || icons.other;
};
