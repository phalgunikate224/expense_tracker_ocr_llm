/**
 * API utility functions for expense tracker
 */

const API_BASE = 'http://localhost:8000';

class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
    this.name = 'ApiError';
  }
}

export const api = {
  // Authentication
  async login(username, password) {
    const formData = new FormData();
    formData.append('username', username);
    formData.append('password', password);
    
    const response = await fetch(`${API_BASE}/token`, {
      method: 'POST',
      body: formData
    });
    
    if (!response.ok) {
      throw new ApiError('Login failed', response.status);
    }
    
    return response.json();
  },

  // Expenses
  async getExpenses(token) {
    const response = await fetch(`${API_BASE}/expenses/`, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (!response.ok) {
      throw new ApiError('Failed to fetch expenses', response.status);
    }
    
    return response.json();
  },

  async createExpense(token, expense) {
    const response = await fetch(`${API_BASE}/expenses/`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(expense)
    });
    
    if (!response.ok) {
      throw new ApiError('Failed to create expense', response.status);
    }
    
    return response.json();
  },

  async updateExpenseStatus(token, expenseId, status) {
    const response = await fetch(`${API_BASE}/expenses/${expenseId}/status`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ status })
    });
    
    if (!response.ok) {
      throw new ApiError('Failed to update expense status', response.status);
    }
    
    return response.json();
  },

  // Chat
  async chatWithExpenses(token, question) {
    const response = await fetch(`${API_BASE}/chat/`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ question })
    });
    
    if (!response.ok) {
      throw new ApiError('Failed to get chat response', response.status);
    }
    
    return response.json();
  },

  // Receipt OCR
  async uploadReceipt(file) {
    const formData = new FormData();
    formData.append('file', file);
    const response = await fetch(`${API_BASE}/upload-receipt/`, {
      method: 'POST',
      body: formData
    });
    if (!response.ok) {
      throw new ApiError('Failed to upload receipt', response.status);
    }
    return response.json();
  },

  async getReceiptResult(taskId) {
    const response = await fetch(`${API_BASE}/receipt-result/${taskId}`);
    if (!response.ok) {
      throw new ApiError('Failed to fetch receipt result', response.status);
    }
    return response.json();
  }
};

export { ApiError };
