import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import App from './App';

// Mock the hooks
jest.mock('./hooks/useAuth', () => ({
  useAuth: () => ({
    token: null,
    isAuthenticated: false,
    loading: false,
    error: null,
    login: jest.fn().mockResolvedValue({ success: true }),
    logout: jest.fn(),
  })
}));

jest.mock('./hooks/useExpenses', () => ({
  useExpenses: () => ({
    expenses: [],
    loading: false,
    error: null,
    fetchExpenses: jest.fn(),
    createExpense: jest.fn(),
    updateExpenseStatus: jest.fn(),
    chatWithExpenses: jest.fn(),
  })
}));

// Mock the components to simplify testing
jest.mock('./components/auth/LoginForm', () => {
  return function DummyLoginForm({ onLogin }) {
    return (
      <div data-testid="login-form">
        <button onClick={() => onLogin('admin', 'admin')}>Login</button>
      </div>
    );
  };
});

jest.mock('./components/ui/Header', () => {
  return function DummyHeader({ onLogout }) {
    return (
      <header data-testid="header">
        <button onClick={onLogout}>Logout</button>
      </header>
    );
  };
});

describe('App Component', () => {
  test('renders login form when not authenticated', () => {
    render(<App />);
    expect(screen.getByTestId('login-form')).toBeInTheDocument();
  });

  test('renders main application when authenticated', () => {
    // Override the mock to return authenticated state
    jest.spyOn(require('./hooks/useAuth'), 'useAuth').mockImplementation(() => ({
      token: 'fake-token',
      isAuthenticated: true,
      loading: false,
      error: null,
      login: jest.fn(),
      logout: jest.fn(),
    }));

    render(<App />);
    expect(screen.getByTestId('header')).toBeInTheDocument();
  });

  test('toggles between tabs when authenticated', () => {
    // Mock authenticated state
    jest.spyOn(require('./hooks/useAuth'), 'useAuth').mockImplementation(() => ({
      token: 'fake-token',
      isAuthenticated: true,
      loading: false,
      error: null,
      login: jest.fn(),
      logout: jest.fn(),
    }));

    render(<App />);
    
    // Check if we can switch tabs
    fireEvent.click(screen.getByText('AI Assistant'));
    expect(screen.getByText('AI Assistant')).toHaveClass('bg-blue-50');
    
    fireEvent.click(screen.getByText('Analytics'));
    expect(screen.getByText('Analytics')).toHaveClass('bg-blue-50');
    
    fireEvent.click(screen.getByText('Expenses'));
    expect(screen.getByText('Expenses')).toHaveClass('bg-blue-50');
  });
});