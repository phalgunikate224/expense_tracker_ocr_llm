import React, { useState } from 'react';
import { Input, Select, Button, Alert } from '../ui';
import { validateExpense } from '../../utils/helpers';
import { api } from '../../utils/api';

const EXPENSE_CATEGORIES = [
  { value: 'meals', label: 'Meals & Food' },
  { value: 'transportation', label: 'Transportation' },
  { value: 'office', label: 'Office Supplies' },
  { value: 'travel', label: 'Travel' },
  { value: 'entertainment', label: 'Entertainment' },
  { value: 'other', label: 'Other' },
];

const ExpenseForm = ({ onSubmit, loading, error }) => {
  const [expense, setExpense] = useState({
    description: '',
    amount: '',
    category: ''
  });
  
  const [validationErrors, setValidationErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [ocrLoading, setOcrLoading] = useState(false);
  const [ocrError, setOcrError] = useState(null);
  const [ocrResult, setOcrResult] = useState(null);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setExpense(prev => ({ ...prev, [name]: value }));
    
    if (submitted) {
      const { errors } = validateExpense({ ...expense, [name]: value });
      setValidationErrors(prev => ({ ...prev, [name]: errors[name] }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitted(true);
    
    // Client-side validation
    const validation = validateExpense(expense);
    setValidationErrors(validation.errors);
    
    if (!validation.isValid) {
      return;
    }
    
    // Submit form
    const success = await onSubmit({
      description: expense.description,
      amount: parseFloat(expense.amount),
      category: expense.category
    });
    
    if (success) {
      setExpense({ description: '', amount: '', category: '' });
      setSubmitSuccess(true);
      setValidationErrors({});
      setTimeout(() => setSubmitSuccess(false), 3000);
    }
  };

  const handleReceiptUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setOcrLoading(true);
    setOcrError(null);
    setOcrResult(null);
    try {
      const { task_id } = await api.uploadReceipt(file);
      // Poll for result
      let attempts = 0;
      let result = null;
      while (attempts < 15) { // ~15s max
        await new Promise(res => setTimeout(res, 1000));
        result = await api.getReceiptResult(task_id);
        if (result.status === 'done') break;
        if (result.status === 'error') throw new Error(result.error || 'OCR failed');
        attempts++;
      }
      if (result.status !== 'done') throw new Error('Timed out waiting for OCR result');
      setOcrResult(result.data);
      // Optionally prefill form fields
      setExpense(prev => ({
        ...prev,
        description: result.data.merchant || prev.description,
        amount: result.data.total ? String(result.data.total) : prev.amount
      }));
    } catch (err) {
      setOcrError(err.message || 'Failed to process receipt');
    } finally {
      setOcrLoading(false);
    }
  };

  return (
    <div className="bg-white shadow-sm rounded-lg p-6">
      <h2 className="text-lg font-medium text-gray-900 mb-4">Add New Expense</h2>
      
      {error && <Alert variant="error" className="mb-4">{error}</Alert>}
      {submitSuccess && <Alert variant="success" className="mb-4">Expense added successfully!</Alert>}
      
      <form onSubmit={handleSubmit}>
        <Input
          label="Description"
          id="description"
          name="description"
          value={expense.description}
          onChange={handleChange}
          placeholder="Business lunch, office supplies, etc."
          error={validationErrors.description}
          required
        />
        
        <Input
          label="Amount ($)"
          id="amount"
          name="amount"
          type="number"
          step="0.01"
          min="0.01"
          value={expense.amount}
          onChange={handleChange}
          placeholder="0.00"
          error={validationErrors.amount}
          required
        />
        
        <Select
          label="Category"
          id="category"
          name="category"
          value={expense.category}
          onChange={handleChange}
          options={[{ value: '', label: 'Select a category' }, ...EXPENSE_CATEGORIES]}
          error={validationErrors.category}
          required
        />
        
        <Button
          type="submit"
          className="w-full mt-4"
          disabled={loading}
        >
          {loading ? 'Adding...' : 'Add Expense'}
        </Button>
      </form>

      {/* Receipt upload UI */}
      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700 mb-1">Upload Receipt (Image)</label>
        <input type="file" accept="image/*" onChange={handleReceiptUpload} disabled={ocrLoading || loading} />
        {ocrLoading && <div className="text-blue-600 text-sm mt-1">Processing receipt...</div>}
        {ocrError && <Alert variant="error" className="mt-2">{ocrError}</Alert>}
        {ocrResult && (
          <div className="mt-2 text-xs bg-gray-50 p-2 rounded border border-gray-200">
            <div><b>Merchant:</b> {ocrResult.merchant}</div>
            <div><b>Date:</b> {ocrResult.date}</div>
            <div><b>Total:</b> {ocrResult.total}</div>
            <div><b>Items:</b> <pre className="whitespace-pre-wrap">{(ocrResult.items || []).join('\n')}</pre></div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ExpenseForm;