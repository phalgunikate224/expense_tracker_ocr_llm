import React, { useState } from 'react';
import { Badge, Button, Card, Spinner } from '../ui';
import { formatCurrency, formatDate, getStatusColor, getCategoryIcon } from '../../utils/helpers';
import { Check, X, Search, RefreshCw, Filter } from 'lucide-react';

const ExpenseList = ({ expenses, onUpdateStatus, onRefresh, loading, error }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [sortBy, setSortBy] = useState('date');
  const [sortDirection, setSortDirection] = useState('desc');

  // Get unique categories from expenses
  const categories = [...new Set(expenses.map(expense => expense.category))];
  
  // Filter and sort expenses
  const filteredExpenses = expenses.filter(expense => {
    const matchesSearch = searchTerm === '' || 
      expense.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = filterCategory === '' || expense.category === filterCategory;
    
    const matchesStatus = filterStatus === '' || expense.status === filterStatus;
    
    return matchesSearch && matchesCategory && matchesStatus;
  });
  
  // Sort expenses
  const sortedExpenses = [...filteredExpenses].sort((a, b) => {
    let comparison = 0;
    
    if (sortBy === 'date') {
      comparison = new Date(a.created_at) - new Date(b.created_at);
    } else if (sortBy === 'amount') {
      comparison = a.amount - b.amount;
    } else if (sortBy === 'description') {
      comparison = a.description.localeCompare(b.description);
    } else if (sortBy === 'category') {
      comparison = a.category.localeCompare(b.category);
    }
    
    return sortDirection === 'asc' ? comparison : -comparison;
  });

  const handleSort = (field) => {
    if (sortBy === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortDirection('desc');
    }
  };
  
  const handleApprove = (expenseId) => {
    onUpdateStatus(expenseId, 'PAID');
  };
  
  const handleReject = (expenseId) => {
    onUpdateStatus(expenseId, 'REJECTED');
  };
  
  // Display empty state when no expenses match filters
  if (!loading && sortedExpenses.length === 0) {
    return (
      <Card className="text-center py-16">
        <h3 className="text-lg font-medium text-gray-900 mb-2">No expenses found</h3>
        <p className="text-gray-600 mb-4">
          {expenses.length > 0
            ? 'Try changing your filters or search term'
            : 'Add your first expense to get started'}
        </p>
        <Button onClick={onRefresh} variant="secondary" className="mt-2">
          <RefreshCw size={16} className="mr-2" />
          Refresh
        </Button>
      </Card>
    );
  }
  
  return (
    <div className="bg-white shadow-sm rounded-lg p-6">
      <div className="flex flex-wrap items-center justify-between mb-6">
        <h2 className="text-lg font-medium text-gray-900">Expenses</h2>
        
        <Button onClick={onRefresh} variant="secondary" size="sm" disabled={loading}>
          <RefreshCw size={16} className="mr-1" />
          Refresh
        </Button>
      </div>
      
      {/* Search and filters */}
      <div className="mb-6 space-y-4">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
            <Search size={18} className="text-gray-400" />
          </div>
          <input
            type="text"
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 p-2.5"
            placeholder="Search expenses..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="flex flex-wrap gap-2">
          {/* Category filter */}
          <select
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 p-2.5"
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
          >
            <option value="">All Categories</option>
            {categories.map(category => (
              <option key={category} value={category}>{category}</option>
            ))}
          </select>
          
          {/* Status filter */}
          <select
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 p-2.5"
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
          >
            <option value="">All Statuses</option>
            <option value="PENDING">Pending</option>
            <option value="PAID">Paid</option>
            <option value="REJECTED">Rejected</option>
          </select>
          
          {/* Sort options */}
          <select
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 p-2.5"
            value={`${sortBy}-${sortDirection}`}
            onChange={(e) => {
              const [field, direction] = e.target.value.split('-');
              setSortBy(field);
              setSortDirection(direction);
            }}
          >
            <option value="date-desc">Latest First</option>
            <option value="date-asc">Oldest First</option>
            <option value="amount-desc">Highest Amount</option>
            <option value="amount-asc">Lowest Amount</option>
            <option value="description-asc">Description (A-Z)</option>
            <option value="category-asc">Category (A-Z)</option>
          </select>
        </div>
      </div>
      
      {/* Loading state */}
      {loading && (
        <div className="flex justify-center items-center py-8">
          <Spinner size="lg" className="border-blue-500" />
          <span className="ml-2 text-gray-600">Loading expenses...</span>
        </div>
      )}
      
      {/* Error state */}
      {error && (
        <div className="bg-red-50 text-red-800 p-4 rounded-lg mb-4">
          {error}
        </div>
      )}
      
      {/* Expenses list */}
      {!loading && (
        <div className="space-y-4">
          {sortedExpenses.map(expense => (
            <div key={expense.id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition">
              <div className="flex justify-between items-start">
                <div className="flex items-start space-x-3">
                  <div className="bg-blue-50 text-blue-600 p-2 rounded-lg">
                    <span className="text-xl">{getCategoryIcon(expense.category)}</span>
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900">{expense.description}</h3>
                    <p className="text-sm text-gray-600">
                      {formatCurrency(expense.amount)} • {expense.category}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      {formatDate(expense.created_at)}
                    </p>
                  </div>
                </div>
                
                <div className="flex flex-col items-end space-y-2">
                  <Badge 
                    variant={expense.status === 'PAID' ? 'success' : expense.status === 'REJECTED' ? 'danger' : 'warning'}
                  >
                    {expense.status}
                  </Badge>
                  
                  {expense.status === 'PENDING' && (
                    <div className="flex space-x-2 mt-2">
                      <Button
                        onClick={() => handleApprove(expense.id)}
                        variant="success"
                        size="xs"
                      >
                        <Check size={14} />
                      </Button>
                      <Button
                        onClick={() => handleReject(expense.id)}
                        variant="danger"
                        size="xs"
                      >
                        <X size={14} />
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      
      {/* Results summary */}
      {!loading && sortedExpenses.length > 0 && (
        <div className="mt-4 text-sm text-gray-500 text-right">
          Showing {sortedExpenses.length} of {expenses.length} expenses
        </div>
      )}
    </div>
  );
};

export default ExpenseList;