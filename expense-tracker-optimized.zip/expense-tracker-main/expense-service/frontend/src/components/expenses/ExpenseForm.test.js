import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import ExpenseForm from './ExpenseForm';

describe('ExpenseForm', () => {
  test('renders expense form correctly', () => {
    render(<ExpenseForm />);
    
    expect(screen.getByLabelText(/Description/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Amount/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Category/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Add Expense/i })).toBeInTheDocument();
  });
  
  test('shows loading state when loading prop is true', () => {
    render(<ExpenseForm loading={true} />);
    expect(screen.getByRole('button', { name: /Adding/i })).toBeInTheDocument();
    expect(screen.getByRole('button')).toBeDisabled();
  });
  
  test('displays error message when error prop is provided', () => {
    const errorMessage = 'Failed to add expense';
    render(<ExpenseForm error={errorMessage} />);
    expect(screen.getByText(errorMessage)).toBeInTheDocument();
  });
  
  test('validates form fields on submit', async () => {
    const mockOnSubmit = jest.fn();
    render(<ExpenseForm onSubmit={mockOnSubmit} />);
    
    // Submit the form without filling it
    fireEvent.click(screen.getByRole('button', { name: /Add Expense/i }));
    
    // Check for validation errors
    await waitFor(() => {
      expect(screen.getByText(/Description is required/i)).toBeInTheDocument();
      expect(screen.getByText(/Amount must be greater than 0/i)).toBeInTheDocument();
      expect(screen.getByText(/Category is required/i)).toBeInTheDocument();
    });
    
    // Ensure onSubmit was not called
    expect(mockOnSubmit).not.toHaveBeenCalled();
  });
  
  test('calls onSubmit with correct data when form is valid', async () => {
    const mockOnSubmit = jest.fn().mockResolvedValue(true);
    render(<ExpenseForm onSubmit={mockOnSubmit} />);
    
    // Fill the form
    fireEvent.change(screen.getByLabelText(/Description/i), { target: { value: 'Business lunch' } });
    fireEvent.change(screen.getByLabelText(/Amount/i), { target: { value: '25.50' } });
    fireEvent.change(screen.getByLabelText(/Category/i), { target: { value: 'meals' } });
    
    // Submit the form
    fireEvent.click(screen.getByRole('button', { name: /Add Expense/i }));
    
    // Check if onSubmit was called with correct data
    await waitFor(() => {
      expect(mockOnSubmit).toHaveBeenCalledWith({
        description: 'Business lunch',
        amount: 25.50,
        category: 'meals'
      });
    });
    
    // Check for success message
    expect(await screen.findByText(/Expense added successfully/i)).toBeInTheDocument();
  });
});