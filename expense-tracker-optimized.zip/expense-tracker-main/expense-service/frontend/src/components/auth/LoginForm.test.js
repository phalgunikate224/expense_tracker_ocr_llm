import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import LoginForm from './LoginForm';

describe('LoginForm', () => {
  test('renders login form correctly', () => {
    render(<LoginForm />);
    
    // Check if important elements are rendered
    expect(screen.getByText(/Expense Tracker/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Username/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Password/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Sign in/i })).toBeInTheDocument();
    expect(screen.getByText(/Test credentials/i)).toBeInTheDocument();
  });
  
  test('shows loading state when loading prop is true', () => {
    render(<LoginForm loading={true} />);
    expect(screen.getByRole('button', { name: /Signing in/i })).toBeInTheDocument();
    expect(screen.getByRole('button')).toBeDisabled();
  });
  
  test('displays error message when error prop is provided', () => {
    const errorMessage = 'Invalid credentials';
    render(<LoginForm error={errorMessage} />);
    expect(screen.getByText(errorMessage)).toBeInTheDocument();
  });
  
  test('calls onLogin with correct credentials when form is submitted', () => {
    const mockOnLogin = jest.fn();
    render(<LoginForm onLogin={mockOnLogin} />);
    
    // Fill in the form
    fireEvent.change(screen.getByLabelText(/Username/i), { target: { value: 'admin' } });
    fireEvent.change(screen.getByLabelText(/Password/i), { target: { value: 'admin' } });
    
    // Submit the form
    fireEvent.click(screen.getByRole('button', { name: /Sign in/i }));
    
    // Check if onLogin was called with correct credentials
    expect(mockOnLogin).toHaveBeenCalledWith('admin', 'admin');
  });
});