import React, { useState } from 'react';
import { Input, Button, Alert } from '../ui';

const LoginForm = ({ onLogin, loading, error }) => {
  const [credentials, setCredentials] = useState({ username: '', password: '' });
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setCredentials(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    onLogin(credentials.username, credentials.password);
  };
  
  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full bg-white rounded-lg shadow-md p-8">
        <div className="text-center">
          <h1 className="text-3xl font-extrabold text-gray-900">Expense Tracker</h1>
          <p className="mt-2 text-sm text-gray-600">Sign in to manage your expenses</p>
        </div>
        
        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          {error && <Alert variant="error">{error}</Alert>}
          
          <Input 
            label="Username"
            id="username"
            name="username"
            type="text"
            value={credentials.username}
            onChange={handleChange}
            placeholder="admin"
            required
            autoFocus
          />
          
          <Input 
            label="Password"
            id="password"
            name="password"
            type="password"
            value={credentials.password}
            onChange={handleChange}
            placeholder="admin"
            required
          />
          
          <Button 
            type="submit" 
            className="w-full py-2.5" 
            disabled={loading}
          >
            {loading ? 'Signing in...' : 'Sign in'}
          </Button>
          
          <div className="text-center">
            <p className="text-xs text-gray-500">
              Test credentials: admin / admin
            </p>
          </div>
        </form>
      </div>
    </div>
  );
};

export default LoginForm;