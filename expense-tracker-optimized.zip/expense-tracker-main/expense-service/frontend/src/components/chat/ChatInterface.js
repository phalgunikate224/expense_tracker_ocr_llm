import React, { useState, useRef, useEffect } from 'react';
import { Send, PanelRightOpen, Loader2 } from 'lucide-react';
import { Card, Button, Badge } from '../ui';
import { formatCurrency } from '../../utils/helpers';

const EXAMPLE_QUESTIONS = [
  "How much did I spend in total?",
  "What's my highest expense category?",
  "Show me pending expenses",
  "What was my last expense?",
  "How many expenses do I have?",
  "What did I spend on meals?"
];

const ChatMessage = ({ message, isUser }) => {
  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-4`}>
      <div 
        className={`max-w-[80%] rounded-lg px-4 py-2 ${
          isUser 
            ? 'bg-blue-600 text-white rounded-br-none' 
            : 'bg-gray-100 text-gray-800 rounded-bl-none'
        }`}
      >
        <p className="text-sm">{message.text}</p>
        
        {!isUser && message.data && (
          <div className="mt-2 pt-2 border-t border-gray-200">
            {message.data.total_spent !== undefined && (
              <p className="text-xs flex justify-between">
                <span>Total Spent:</span> 
                <span className="font-medium">{formatCurrency(message.data.total_spent)}</span>
              </p>
            )}
            
            {message.data.expense_count !== undefined && (
              <p className="text-xs flex justify-between">
                <span>Expense Count:</span> 
                <span className="font-medium">{message.data.expense_count}</span>
              </p>
            )}
            
            {message.data.spend_by_category && Object.keys(message.data.spend_by_category).length > 0 && (
              <div className="mt-1">
                <p className="text-xs mb-1">Category Breakdown:</p>
                {Object.entries(message.data.spend_by_category).map(([category, amount]) => (
                  <div key={category} className="flex justify-between text-xs">
                    <span className="capitalize">{category}:</span>
                    <span className="font-medium">{formatCurrency(amount)}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

const ChatInterface = ({ onSendMessage, loading, error }) => {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([
    { id: 1, text: "Hello! I'm your AI expense assistant. Ask me anything about your expenses.", isUser: false }
  ]);
  const messagesEndRef = useRef(null);

  // Auto-scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!input.trim()) return;
    
    const userMessage = { id: Date.now(), text: input, isUser: true };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    
    try {
      const response = await onSendMessage(input);
      
      setMessages(prev => [...prev, {
        id: Date.now(),
        text: response.answer,
        data: response.data,
        isUser: false
      }]);
      
    } catch (err) {
      setMessages(prev => [...prev, {
        id: Date.now(),
        text: error || "Sorry, I couldn't process your question. Please try again.",
        isUser: false
      }]);
    }
  };
  
  const handleExampleClick = (question) => {
    setInput(question);
  };

  return (
    <div className="flex flex-col h-full">
      {/* Chat header */}
      <div className="bg-white p-4 border-b">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="bg-blue-100 text-blue-800 p-2 rounded-lg mr-3">
              <PanelRightOpen size={20} />
            </div>
            <div>
              <h2 className="font-medium text-gray-900">AI Expense Assistant</h2>
              <p className="text-sm text-gray-500">Ask questions about your expenses</p>
            </div>
          </div>
          <Badge variant="primary">GPT4All</Badge>
        </div>
      </div>
      
      {/* Chat messages */}
      <div className="flex-1 overflow-y-auto p-4 bg-gray-50">
        {messages.map(message => (
          <ChatMessage key={message.id} message={message} isUser={message.isUser} />
        ))}
        <div ref={messagesEndRef} />
        
        {loading && (
          <div className="flex justify-center items-center py-4">
            <Loader2 size={20} className="animate-spin text-blue-500 mr-2" />
            <span className="text-sm text-gray-500">Thinking...</span>
          </div>
        )}
      </div>
      
      {/* Example questions */}
      <div className="bg-gray-50 px-4 py-2 border-t border-gray-100">
        <p className="text-xs text-gray-500 mb-2">Try asking:</p>
        <div className="flex flex-wrap gap-2">
          {EXAMPLE_QUESTIONS.map((question) => (
            <button
              key={question}
              onClick={() => handleExampleClick(question)}
              className="text-xs bg-white border border-gray-200 rounded-full px-3 py-1 hover:bg-gray-100"
            >
              {question}
            </button>
          ))}
        </div>
      </div>
      
      {/* Chat input */}
      <div className="bg-white p-4 border-t">
        <form onSubmit={handleSubmit} className="flex items-center">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about your expenses..."
            className="flex-1 px-4 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            disabled={loading}
          />
          <Button
            type="submit"
            className="rounded-l-none"
            disabled={loading || !input.trim()}
          >
            <Send size={18} />
          </Button>
        </form>
      </div>
    </div>
  );
};

export default ChatInterface;