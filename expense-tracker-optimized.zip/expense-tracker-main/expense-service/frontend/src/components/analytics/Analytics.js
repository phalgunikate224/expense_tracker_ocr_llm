import React from 'react';
import { Card } from '../ui';
import { formatCurrency } from '../../utils/helpers';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { DollarSign, CreditCard, TrendingUp, ShoppingBag } from 'lucide-react';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

const StatCard = ({ title, value, icon, change, color = 'blue' }) => {
  const IconComponent = icon;
  
  return (
    <Card className="flex items-start">
      <div className={`rounded-lg p-2 bg-${color}-100 text-${color}-600 mr-4`}>
        <IconComponent size={24} />
      </div>
      <div>
        <h3 className="text-sm font-medium text-gray-500">{title}</h3>
        <p className="text-2xl font-bold text-gray-900">{value}</p>
        {change && (
          <p className={`text-xs ${change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
            {change >= 0 ? '+' : ''}{change}% from last month
          </p>
        )}
      </div>
    </Card>
  );
};

const Analytics = ({ expenses, loading, error }) => {
  // Calculate statistics from expenses
  const stats = React.useMemo(() => {
    if (!expenses || expenses.length === 0) {
      return {
        totalAmount: 0,
        averageAmount: 0,
        totalCount: 0,
        pendingCount: 0,
        paidCount: 0,
        rejectedCount: 0,
        categoryData: [],
        statusData: [],
        recentTrend: []
      };
    }
    
    // Calculate total and average amounts
    const totalAmount = expenses.reduce((sum, exp) => sum + exp.amount, 0);
    const averageAmount = totalAmount / expenses.length;
    
    // Count expenses by status
    const pendingCount = expenses.filter(exp => exp.status === 'PENDING').length;
    const paidCount = expenses.filter(exp => exp.status === 'PAID').length;
    const rejectedCount = expenses.filter(exp => exp.status === 'REJECTED').length;
    
    // Calculate category data for charts
    const categoryMap = expenses.reduce((acc, exp) => {
      const category = exp.category || 'Other';
      acc[category] = (acc[category] || 0) + exp.amount;
      return acc;
    }, {});
    
    const categoryData = Object.entries(categoryMap).map(([name, value]) => ({
      name,
      value
    }));
    
    // Status data for charts
    const statusData = [
      { name: 'Pending', value: pendingCount },
      { name: 'Paid', value: paidCount },
      { name: 'Rejected', value: rejectedCount }
    ].filter(item => item.value > 0);
    
    // Generate recent trend (last 7 days)
    const today = new Date();
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = new Date(today);
      date.setDate(today.getDate() - (6 - i));
      return date.toISOString().split('T')[0];
    });
    
    const dailyExpenses = expenses.reduce((acc, exp) => {
      const day = new Date(exp.created_at).toISOString().split('T')[0];
      acc[day] = (acc[day] || 0) + exp.amount;
      return acc;
    }, {});
    
    const recentTrend = last7Days.map(day => {
      const dayName = new Date(day).toLocaleDateString('en-US', { weekday: 'short' });
      return {
        name: dayName,
        amount: dailyExpenses[day] || 0
      };
    });
    
    return {
      totalAmount,
      averageAmount,
      totalCount: expenses.length,
      pendingCount,
      paidCount,
      rejectedCount,
      categoryData,
      statusData,
      recentTrend
    };
  }, [expenses]);

  if (loading) {
    return (
      <div className="text-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500 mx-auto"></div>
        <p className="mt-4 text-gray-600">Loading analytics...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 text-red-800 p-4 rounded-lg">
        {error}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Summary stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard 
          title="Total Expenses" 
          value={formatCurrency(stats.totalAmount)}
          icon={DollarSign}
          color="blue"
          change={3.2}
        />
        <StatCard 
          title="Avg. Expense" 
          value={formatCurrency(stats.averageAmount)}
          icon={TrendingUp}
          color="green"
        />
        <StatCard 
          title="Total Transactions" 
          value={stats.totalCount}
          icon={CreditCard}
          color="purple"
          change={-1.5}
        />
        <StatCard 
          title="Pending Approval" 
          value={stats.pendingCount}
          icon={ShoppingBag}
          color="yellow"
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Category distribution */}
        <Card className="p-4">
          <h3 className="text-lg font-medium mb-4">Spending by Category</h3>
          <div className="h-80">
            {stats.categoryData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={stats.categoryData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(1)}%`}
                  >
                    {stats.categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => formatCurrency(value)} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-gray-500">
                No category data available
              </div>
            )}
          </div>
        </Card>

        {/* Expense trend */}
        <Card className="p-4">
          <h3 className="text-lg font-medium mb-4">Recent Spending Trend</h3>
          <div className="h-80">
            {stats.recentTrend.some(day => day.amount > 0) ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats.recentTrend}>
                  <XAxis dataKey="name" />
                  <YAxis tickFormatter={(value) => `$${value}`} />
                  <Tooltip formatter={(value) => formatCurrency(value)} />
                  <Bar dataKey="amount" fill="#0088FE" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-gray-500">
                No recent spending data available
              </div>
            )}
          </div>
        </Card>
      </div>

      {/* Status breakdown */}
      <Card className="p-4">
        <h3 className="text-lg font-medium mb-4">Expense Status</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 text-center">
            <p className="text-yellow-800 text-sm font-medium">Pending</p>
            <p className="text-2xl font-bold text-yellow-600">{stats.pendingCount}</p>
          </div>
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-center">
            <p className="text-green-800 text-sm font-medium">Approved</p>
            <p className="text-2xl font-bold text-green-600">{stats.paidCount}</p>
          </div>
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-center">
            <p className="text-red-800 text-sm font-medium">Rejected</p>
            <p className="text-2xl font-bold text-red-600">{stats.rejectedCount}</p>
          </div>
        </div>
        
        <div className="h-48">
          {stats.statusData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.statusData}>
                <XAxis dataKey="name" />
                <YAxis allowDecimals={false} />
                <Tooltip />
                <Bar dataKey="value" fill="#8884d8" />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex items-center justify-center text-gray-500">
              No status data available
            </div>
          )}
        </div>
      </Card>
    </div>
  );
};

export default Analytics;