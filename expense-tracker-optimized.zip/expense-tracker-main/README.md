# Expense Tracker

A modern, full-stack expense tracking system with AI-powered receipt OCR and natural language analytics.

## Features

- **Expense Management:** Add, view, and categorize expenses with status tracking (Pending, Paid, Reimbursed, Rejected).
- **Receipt OCR:** Upload receipt images and extract merchant, date, total, and line items using Tesseract OCR.
- **AI Assistant:** Ask questions about your expenses using a local LLM (with fallback to rule-based answers).
- **Analytics:** Visualize spending by category, status, and trends.
- **Authentication:** Secure login with JWT.
- **Modern UI:** Built with React and Tailwind CSS.

## Tech Stack

- **Frontend:** React, Tailwind CSS
- **Backend:** FastAPI, SQLAlchemy, Celery, Redis
- **OCR:** Tesseract (via pytesseract)
- **AI:** gpt4all (local LLM) with fallback logic
- **Database:** SQLite (default, can be swapped)

## Quick Start

### Prerequisites
- Python 3.9+
- Node.js 16+
- Redis (for Celery)
- Tesseract OCR (`brew install tesseract` on macOS)

### Backend Setup
```bash
cd expense-service/backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
# Start FastAPI
uvicorn app.main:app --reload
# Start Celery worker (in another terminal)
celery -A app.tasks worker --loglevel=info
```

### Frontend Setup
```bash
cd expense-service/frontend
npm install
npm start
```

### Usage
- Visit `http://localhost:3000` for the frontend.
- Login or register.
- Add expenses, upload receipts, and interact with the AI assistant.

### Receipt OCR
- Upload a receipt image in the "Add Expense" form.
- The backend will extract merchant, date, total, and line items.
- You can confirm or edit the extracted data before saving.

### AI Assistant
- Ask questions like "What are my pending expenses?" or "How much did I spend on meals this month?"
- The system uses a local LLM if available, otherwise falls back to rule-based answers.

## Architecture

The Expense Tracker is a modular, service-oriented application with clear separation between frontend, backend, and asynchronous task processing. Here’s an expanded overview of the architecture and AI integration:

### System Overview
- **Frontend (React + Tailwind CSS):**
  - Handles all user interactions: authentication, expense management, receipt upload, analytics dashboards, and the chat interface for the AI assistant.
  - Communicates with the backend via REST APIs.
  - Provides real-time feedback for long-running tasks (e.g., OCR, LLM queries) by polling task status.
  - Implements optimistic UI updates and error handling for a smooth user experience.
- **Backend (FastAPI):**
  - Exposes RESTful endpoints for all business logic: user management, expense CRUD, status updates, and AI chat.
  - Handles authentication and authorization using JWT tokens.
  - Delegates resource-intensive or asynchronous tasks (OCR, LLM) to Celery workers.
  - Implements input validation and error handling using Pydantic schemas.
- **Celery Worker:**
  - Runs in a separate process, connected to the backend via Redis (as a message broker).
  - Handles background jobs such as OCR extraction and LLM-based question answering.
  - Returns results to the backend, which are then relayed to the frontend.
  - Can be scaled horizontally for high-throughput scenarios.
- **Database (SQLite by default):**
  - Stores all persistent data: users, expenses, extracted receipt fields, and chat logs.
  - Can be swapped for PostgreSQL, MySQL, or other SQL databases with minimal changes.
  - Uses SQLAlchemy ORM for database access and migrations.
- **OCR (Tesseract via pytesseract):**
  - Processes uploaded receipt images to extract merchant, date, total, and line items.
  - Results are parsed and stored in the database for further use and analytics.
  - Handles image preprocessing for improved OCR accuracy.
- **AI/LLM (gpt4all):**
  - Used for natural language queries about expenses.
  - Runs locally for privacy and cost efficiency.
  - Fallback to rule-based logic if LLM is unavailable or times out.
  - Supports prompt engineering for better contextual answers.

### LLM Tools Used
- **gpt4all:**
  - An open-source, local LLM integrated via Python bindings.
  - Supports on-device inference, ensuring user data never leaves the local environment.
  - Used for answering natural language queries, summarizing expenses, and providing analytics insights.
  - Can be replaced with other LLMs (e.g., Llama.cpp, OpenAI API) with minimal code changes.
- **pytesseract:**
  - Python wrapper for Tesseract OCR, used for extracting text from receipt images.
- **Celery:**
  - Distributed task queue for running OCR and LLM jobs asynchronously.
- **Redis:**
  - Message broker for Celery, enabling scalable background processing.
- **Fallback Logic:**
  - If the LLM is not available, the backend uses deterministic, rule-based logic to answer common queries (e.g., SQL queries + template responses).

### How Data from DB is Added to LLM
- **Retrieval-Augmented Generation (RAG):**
  - When a user submits a question, the backend first queries the database for relevant expense data (e.g., all expenses, expenses by category, status, or date range).
  - The retrieved data is formatted as a structured context (e.g., a summary table, CSV, or JSON snippet) and prepended to the user’s question.
  - This combined prompt (context + question) is sent to the LLM, enabling it to generate answers grounded in the actual user data.
  - Example prompt sent to LLM:
    ```json
    Context:
    [
      {"date": "2025-05-01", "merchant": "Starbucks", "amount": 5.25, "category": "Meals", "status": "PAID"},
      {"date": "2025-05-02", "merchant": "Uber", "amount": 12.00, "category": "Transport", "status": "PENDING"},
      ...
    ]
    Question: How much did I spend on meals this month?
    ```
  - The LLM uses this context to generate accurate, up-to-date answers.
  - If the LLM fails or times out, the backend falls back to a rule-based answer (e.g., SQL aggregation + template response).
  - The RAG approach can be extended to support more complex analytics, summaries, or even conversational memory.

#### Why RAG?
- **Accuracy:** Ensures the LLM’s answers are always based on the latest data.
- **Privacy:** No sensitive data is sent to external servers; all processing is local.
- **Flexibility:** Supports a wide range of queries, from simple totals to complex analytics.
- **Explainability:** The context sent to the LLM can be logged for audit and debugging.

### Key Techniques
- **Asynchronous Task Processing:**
  - OCR and LLM queries are handled by Celery workers to keep the API responsive and scalable.
  - The frontend polls for task completion and updates the UI when results are ready.
- **Contextual Prompting:**
  - Database results are injected into the LLM prompt for retrieval-augmented generation.
  - Prompts are carefully formatted to maximize LLM comprehension and accuracy.
- **Fallback Handling:**
  - If the LLM fails, the backend provides rule-based answers and logs the fallback event for monitoring.
- **Extensibility:**
  - The architecture supports swapping out the LLM, database, or OCR engine with minimal code changes.
- **Security:**
  - All endpoints are protected with JWT authentication.
  - Sensitive data is never sent to third-party APIs.
- **Testing:**
  - Includes unit and integration tests for backend logic, OCR, and LLM flows.

### Example LLM Query Flow
1. User asks: "How much did I spend on meals this month?"
2. Backend queries the database for all expenses in the "Meals" category for the current month.
3. Backend formats the data as context and combines it with the user’s question.
4. Celery worker sends the prompt to gpt4all and waits for a response.
5. LLM generates a natural language answer (e.g., "You spent $123.45 on meals in May 2025.").
6. If LLM fails, backend computes the answer directly and returns a template response.
7. The answer is returned to the frontend and displayed in the chat interface.

### Extending the System
- **Add new LLMs:** Swap out gpt4all for other local or cloud-based LLMs by updating the Celery task and prompt logic.
- **Advanced analytics:** Add new endpoints and prompt templates for more complex queries (e.g., trends, forecasts).
- **Integrations:** Connect to external APIs (e.g., bank feeds) for automated expense import.
- **Mobile support:** Extend the frontend for mobile devices or build a native app using the same API.

## Project Structure

```
expense-service/
  backend/
    app/
      main.py         # FastAPI app
      tasks.py        # Celery tasks (OCR, LLM)
      models.py       # SQLAlchemy models
      schemas.py      # Pydantic schemas
      ...
    requirements.txt
    Dockerfile
  frontend/
    src/
      App.jsx         # Main React app
      components/     # UI components
      hooks/          # React hooks
      utils/          # API and helpers
    package.json
```

## Troubleshooting
- **OCR Timeout:** Ensure Tesseract is installed and the Celery worker is running.
- **422 on status update:** Make sure the backend enum includes all statuses (PENDING, PAID, REIMBURSED, REJECTED).
- **LLM fallback:** If the LLM cannot load, the system will use rule-based answers and log this in the backend.

## Contributing
Pull requests are welcome! Please open an issue first to discuss major changes.

## License
MIT
